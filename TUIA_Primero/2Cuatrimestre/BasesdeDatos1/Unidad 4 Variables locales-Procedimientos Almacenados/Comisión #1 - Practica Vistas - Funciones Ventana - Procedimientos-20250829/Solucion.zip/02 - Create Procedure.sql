CREATE PROCEDURE pProductosConMuchoStockDeUnaCategoria
( @pID_Categoria INT, @pCantidad INT OUTPUT)
AS
BEGIN 
	--
	SELECT @pCantidad = COUNT(*)
	FROM vProductosEnStock
	WHERE PorcentajeCategoria >= 10
	AND CategoryID = @pID_Categoria;
	--
	SELECT *
	FROM vProductosEnStock
	WHERE PorcentajeCategoria >= 10
	AND CategoryID = @pID_Categoria;
	--
END;