CREATE OR ALTER VIEW [dbo].[vProductosEnStock] AS
SELECT	p.ProductName,
		c.CategoryID,
		c.CategoryName,
		p.UnitsInStock,
		CAST( p.UnitsInStock * 100.0 / SUM(p.UnitsInStock) OVER(PARTITION BY p.CategoryID) AS DECIMAL(5,2)) AS PorcentajeCategoria
  FROM Products p
  JOIN Categories c ON c.CategoryID = p.CategoryID
GO