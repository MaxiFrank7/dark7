DECLARE @vCantidad INT
--
EXEC pProductosConMuchoStockDeUnaCategoria 4, @vCantidad OUTPUT
--
SELECT @vCantidad AS CantidadDeRegistrosDevueltos;